```

BenchmarkDotNet v0.13.12, macOS 15.5 (24F74) [Darwin 24.5.0]
Apple M2 Max, 1 CPU, 12 logical and 12 physical cores
.NET SDK 8.0.408
  [Host]     : .NET 8.0.15 (8.0.1525.16413), Arm64 RyuJIT AdvSIMD
  Job-TPYSCQ : .NET 8.0.15 (8.0.1525.16413), Arm64 RyuJIT AdvSIMD

InvocationCount=1  RunStrategy=Monitoring  UnrollFactor=1  
WarmupCount=3  

```
| Method                | Mean     | Error    | StdDev   | Gen0   | Gen1   | Allocated |
|---------------------- |---------:|---------:|---------:|-------:|-------:|----------:|
| Open_WithPlugins      | 411.3 ns |  7.39 ns |  4.89 ns | 0.2860 |      - |    2408 B |
| Open_WithNoPlugins    | 186.7 ns | 91.82 ns | 60.73 ns | 0.0480 |      - |     408 B |
| Execute_WithPlugins   | 421.6 ns | 20.43 ns | 13.51 ns | 0.1700 | 0.0840 |    1432 B |
| Execute_WithNoPlugins | 252.3 ns | 38.47 ns | 25.45 ns | 0.0360 | 0.0180 |     312 B |
